
import React, { createContext, useState, useContext, ReactNode } from 'react';
import type { CartItem, Product } from '../types';

// Define the shape of the context's value.
interface CartContextType {
    cartItems: CartItem[];
    addToCart: (product: Product, quantity?: number) => void;
    removeFromCart: (productId: number) => void;
    updateQuantity: (productId: number, quantity: number) => void;
    cartCount: number;
    totalPrice: number;
}

// Create the context with an initial value of undefined.
const CartContext = createContext<CartContextType | undefined>(undefined);

// Helper function to parse a price string (e.g., "PKR 5,499") into a number.
const parsePrice = (priceStr: string): number => {
    return Number(priceStr.replace(/[^0-9.-]+/g,""));
}

/**
 * The provider component that wraps the app and makes cart data available.
 */
export const CartProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
    // State to hold the array of items in the cart.
    const [cartItems, setCartItems] = useState<CartItem[]>([]);

    /**
     * Adds a product to the cart. If the product is already in the cart, it increments the quantity.
     * @param product The product to add.
     * @param quantity The number of items to add. Defaults to 1.
     */
    const addToCart = (product: Product, quantity: number = 1) => {
        setCartItems(prevItems => {
            const existingItem = prevItems.find(item => item.id === product.id);
            if (existingItem) {
                // If item exists, map over the array and update the quantity of the matching item.
                return prevItems.map(item =>
                    item.id === product.id ? { ...item, quantity: item.quantity + quantity } : item
                );
            }
            // If item doesn't exist, add it to the array with the specified quantity.
            return [...prevItems, { ...product, quantity: quantity }];
        });
    };

    /**
     * Removes an item completely from the cart, regardless of quantity.
     * @param productId The ID of the product to remove.
     */
    const removeFromCart = (productId: number) => {
        setCartItems(prevItems => prevItems.filter(item => item.id !== productId));
    };

    /**
     * Updates the quantity of a specific item in the cart.
     * If the quantity drops to 0 or less, the item is removed.
     * @param productId The ID of the product to update.
     * @param quantity The new quantity.
     */
    const updateQuantity = (productId: number, quantity: number) => {
        if (quantity <= 0) {
            removeFromCart(productId);
        } else {
            setCartItems(prevItems =>
                prevItems.map(item =>
                    item.id === productId ? { ...item, quantity } : item
                )
            );
        }
    };

    // Derived state: Calculate the total number of items in the cart.
    const cartCount = cartItems.reduce((count, item) => count + item.quantity, 0);

    // Derived state: Calculate the total price of all items in the cart.
    const totalPrice = cartItems.reduce((total, item) => {
        return total + parsePrice(item.price) * item.quantity;
    }, 0);

    // Provide the cart state and action functions to children components.
    return (
        <CartContext.Provider value={{ cartItems, addToCart, removeFromCart, updateQuantity, cartCount, totalPrice }}>
            {children}
        </CartContext.Provider>
    );
};

/**
 * Custom hook to easily consume the CartContext in other components.
 * It also handles the case where the context is used outside of a CartProvider.
 */
export const useCart = () => {
    const context = useContext(CartContext);
    if (context === undefined) {
        throw new Error('useCart must be used within a CartProvider');
    }
    return context;
};