



import React, { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { AnimatePresence, motion, Variants } from 'framer-motion';
import { PRODUCTS, TESTIMONIALS } from '../constants';
import ProductCard from '../components/ProductCard';
import AnimatedSection from '../components/AnimatedSection';
import Icon from '../components/Icon';
import QuickViewModal from '../components/QuickViewModal';
import type { Product } from '../types';
import SaleBanner from '../components/SaleBanner';
import CategoryGrid from '../components/CategoryGrid';

/**
 * The hero section, redesigned to be vibrant and modern based on the user's image.
 */
const HeroSection: React.FC = () => {
    // Animation variants for staggered fade-in effect
    const containerVariants: Variants = {
        hidden: { opacity: 0 },
        visible: {
            opacity: 1,
            transition: { staggerChildren: 0.1, delayChildren: 0.2 },
        },
    };

    const itemVariants: Variants = {
        hidden: { opacity: 0, y: 20 },
        visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: 'easeOut' } },
    };

    return (
        <motion.section
            className="bg-white text-brand-primary pt-32 pb-16 overflow-hidden"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
        >
            <div className="container mx-auto px-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-x-8 gap-y-8">
                    {/* Left side: Heading and two images */}
                    <div className="flex flex-col gap-8">
                        {/* Heading */}
                        <motion.div variants={itemVariants} className="relative z-10">
                            <h1 className="text-5xl md:text-6xl lg:text-7xl font-extrabold tracking-tighter leading-tight">
                                Discover <span className="text-brand-accent">Fashion</span><br />
                                That Speaks to You
                            </h1>
                            <Link to="/shop" className="mt-8 bg-black text-white font-bold py-3 px-8 rounded-full transition-transform duration-300 hover:scale-105 inline-block text-center shadow-lg">
                                Shop Now
                            </Link>
                        </motion.div>

                        {/* Two bottom images */}
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                            <motion.div variants={itemVariants} className="relative h-96 lg:h-[500px] group">
                                <div className="absolute -inset-2 bg-hero-green rounded-3xl rotate-3 transition-transform group-hover:scale-105"></div>
                                <div className="absolute inset-0 p-4 flex flex-col justify-end">
                                    <img
                                        src="https://images.unsplash.com/photo-1617062554652-b92556647ef9?w=600&h=800&fit=crop&q=80"
                                        alt="Stylish woman posing in a modern outfit"
                                        className="absolute inset-0 w-full h-full object-cover rounded-3xl"
                                    />
                                    <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-3xl"></div>
                                    <Link to="/shop" className="relative self-start bg-white/80 backdrop-blur-sm text-black rounded-full px-5 py-2 text-sm font-semibold hover:bg-white transition-colors">
                                        Shop Now
                                    </Link>
                                </div>
                            </motion.div>

                             <motion.div variants={itemVariants} className="relative h-96 lg:h-[500px]">
                                <div className="absolute -inset-2 bg-brand-accent rounded-3xl -rotate-2"></div>
                                <div className="absolute inset-0 w-full h-full overflow-hidden rounded-3xl">
                                    <svg className="absolute -top-1/4 -left-1/4 w-[150%] h-[150%] text-yellow-300 opacity-80" viewBox="0 0 100 100" preserveAspectRatio="none">
                                        <path d="M0,50 Q25,0 50,50 T100,50" fill="currentColor" stroke="none" />
                                        <path d="M0,60 Q25,110 50,60 T100,60" fill="currentColor" stroke="none" />
                                    </svg>
                                </div>
                                <img
                                    src="https://images.unsplash.com/photo-1646670478813-8ff2235abc3a?q=80&w=387&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
                                    alt="Stylish person in a vibrant yellow outfit posing against a blue wall"
                                    className="absolute inset-0 w-full h-full object-cover rounded-3xl"
                                />
                            </motion.div>
                        </div>
                    </div>
                    
                    {/* Right side: Description, image, and offer */}
                    <div className="flex flex-col gap-8">
                         <motion.div variants={itemVariants}>
                            <p className="text-gray-500 max-w-sm text-base leading-relaxed">
                                Step into a world of fashion where every piece tells a story—your story. From casual essentials to statement outfits.
                            </p>
                         </motion.div>

                         <motion.div variants={itemVariants} className="relative h-96 lg:h-[400px] flex-grow">
                           <div className="absolute -inset-2 bg-hero-purple rounded-3xl -rotate-2"></div>
                           <img
                                src="https://images.unsplash.com/photo-1611885716813-13e24e52fb28?w=600&h=800&fit=crop&q=80"
                                alt="Stylish man posing against a textured wall"
                                className="absolute inset-0 w-full h-full object-cover rounded-3xl"
                            />
                         </motion.div>
                         
                         <motion.div variants={itemVariants} className="relative h-64 flex items-center justify-center">
                            <div className="relative w-full h-full rounded-3xl shadow-lg rotate-2 overflow-hidden">
                                <img
                                    src="https://images.unsplash.com/photo-1549057446-9f5c6ac91a04?w=800&h=600&fit=crop&q=80"
                                    alt="Stylish sunglasses and accessories on a bright background"
                                    className="absolute inset-0 w-full h-full object-cover"
                                />
                                {/* A semi-transparent overlay with a blur effect to create the requested "light blur shadow" and ensure text readability. */}
                                <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-black/10 backdrop-blur-sm"></div>
                                <div className="relative w-full h-full p-8 flex flex-col items-center justify-center text-center text-white">
                                    <h2 className="text-3xl font-bold mb-2 drop-shadow-lg">Get 20% Off</h2>
                                    <p className="text-lg mb-4 drop-shadow-md">On All Accessories</p>
                                    <Link to="/sale" className="border-2 border-white/50 bg-white/10 hover:bg-white/20 text-white font-semibold py-2 px-6 rounded-full transition-colors duration-300">
                                        Shop The Sale
                                    </Link>
                                </div>
                            </div>
                         </motion.div>
                    </div>
                </div>
            </div>
        </motion.section>
    );
};


/**
 * A section to display a curated list of featured products in a slider.
 */
const FeaturedProducts: React.FC<{ onQuickView: (product: Product) => void }> = ({ onQuickView }) => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollContainerRef.current) {
      const { current } = scrollContainerRef;
      // Scroll by a little less than the container's width to hint there's more content
      const scrollAmount = current.clientWidth * 0.9;
      current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth',
      });
    }
  };

  return (
    <section className="py-20 bg-brand-secondary">
      <div className="container mx-auto px-6">
        <div className="relative">
            <div className="absolute -inset-2 md:-inset-3 bg-brand-accent rounded-3xl rotate-1 transition-transform duration-300 ease-in-out"></div>
            <div 
                className="bg-white py-16 relative overflow-hidden rounded-2xl z-10"
            >
              {/* Decorative background text */}
              <div
                  className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-7xl sm:text-9xl md:text-[140px] lg:text-[180px] font-black text-gray-500/10 leading-none select-none pointer-events-none"
                  aria-hidden="true"
              >
                  COLLECTION
              </div>
              
              <AnimatedSection className="relative text-center px-6 md:px-12">
                <h2 className="text-3xl md:text-4xl font-bold mb-4 font-serif text-brand-primary">Our Collection</h2>
                <p className="text-gray-600 mb-12 max-w-lg mx-auto">Discover our hand-picked selection of must-have items for this season.</p>
              </AnimatedSection>

              <AnimatedSection className="relative px-0 md:px-4" delay={0.2}>
                {/* Navigation buttons for the slider */}
                <button
                  onClick={() => scroll('left')}
                  className="absolute left-2 md:left-8 top-1/2 -translate-y-1/2 z-20 bg-white/80 hover:bg-white p-2 rounded-full shadow-lg transition-all duration-300 hidden md:flex items-center justify-center cursor-pointer"
                  aria-label="Scroll left"
                >
                  <Icon name="arrow-left" className="w-6 h-6 text-brand-primary" />
                </button>
                <button
                  onClick={() => scroll('right')}
                  className="absolute right-2 md:right-8 top-1/2 -translate-y-1/2 z-20 bg-white/80 hover:bg-white p-2 rounded-full shadow-lg transition-all duration-300 hidden md:flex items-center justify-center cursor-pointer"
                  aria-label="Scroll right"
                >
                  <Icon name="arrow-right" className="w-6 h-6 text-brand-primary" />
                </button>

                <div
                  ref={scrollContainerRef}
                  className="flex overflow-x-auto snap-x snap-mandatory scroll-smooth scrollbar-hide gap-8 px-6 md:px-12"
                >
                  {/* This is a hack for webkit browsers to hide the scrollbar */}
                  <style>{`.scrollbar-hide::-webkit-scrollbar { display: none; } .scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }`}</style>
                  
                  {/* Display more products for the slider */}
                  {PRODUCTS.slice(0, 8).map((product) => (
                    <div key={product.id} className="snap-center shrink-0 w-[75vw] sm:w-64 md:w-72">
                        <ProductCard product={product} onQuickView={onQuickView} theme="light" />
                    </div>
                  ))}
                </div>
              </AnimatedSection>
              
              <AnimatedSection className="relative text-center mt-12" delay={0.4}>
                  <Link to="/shop" className="bg-brand-primary hover:bg-black text-white font-bold py-3 px-10 rounded-full transition-transform duration-300 hover:scale-105 inline-block shadow-lg">
                      View All Products
                  </Link>
              </AnimatedSection>
            </div>
        </div>
      </div>
    </section>
  );
};

/**
 * A brief introductory section about the brand.
 */
const AboutIntro: React.FC = () => {
    return (
        <section className="py-20 bg-white">
            <div className="container mx-auto px-6">
                <div className="relative">
                    {/* Decorative border */}
                    <div className="absolute -inset-2 md:-inset-3 bg-brand-accent rounded-3xl rotate-2 transition-transform duration-300 ease-in-out"></div>
                    
                    {/* Main content container */}
                    <div className="relative bg-white rounded-2xl z-10 p-8 md:p-12 lg:p-16">
                        <div className="grid md:grid-cols-2 gap-12 items-center">
                            <AnimatedSection>
                                <div className="relative">
                                     <div className="absolute -inset-2 bg-brand-accent rounded-2xl -rotate-3 transition-transform duration-300 ease-in-out"></div>
                                     <img src="https://plus.unsplash.com/premium_photo-1707988181112-2f529c528444?w=800&h=1000&fit=crop&q=80" alt="Group of stylish friends" className="relative z-10 rounded-lg shadow-xl object-cover w-full h-full"/>
                                </div>
                            </AnimatedSection>
                            <AnimatedSection delay={0.2}>
                                <h2 className="text-3xl font-bold font-serif mb-4 text-brand-primary">Crafted with Passion</h2>
                                <p className="text-gray-600 mb-6 leading-relaxed">
                                    ModeMystic was born from a desire to blend contemporary design with timeless quality. We believe that what you wear is a form of self-expression, a way to tell your own unique story without saying a word.
                                </p>
                                <Link to="/about" className="text-brand-accent font-bold hover:underline">
                                    Our Story &rarr;
                                </Link>
                            </AnimatedSection>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

/**
 * A section to display customer testimonials as an auto-sliding carousel.
 */
const Testimonials: React.FC = () => {
    const [currentIndex, setCurrentIndex] = useState(0);

    // Effect to handle the auto-sliding functionality
    useEffect(() => {
        const timer = setInterval(() => {
            setCurrentIndex((prevIndex) => (prevIndex + 1) % TESTIMONIALS.length);
        }, 5000); // Change slide every 5 seconds

        return () => clearInterval(timer); // Cleanup timer on component unmount
    }, []);

    const goToSlide = (index: number) => {
        setCurrentIndex(index);
    };

    return (
        <section className="py-20 bg-brand-secondary">
            <div className="container mx-auto px-6">
                 <div className="relative">
                    {/* Decorative border */}
                    <div className="absolute -inset-2 md:-inset-3 bg-hero-brown rounded-3xl -rotate-1 transition-transform duration-300 ease-in-out"></div>
                    
                    {/* Main content container */}
                    <div className="relative bg-white rounded-2xl z-10 p-8 md:p-12 lg:p-16 overflow-hidden">
                        <AnimatedSection>
                            <h2 className="text-3xl font-bold text-center font-serif mb-4 text-brand-primary">What Our Customers Say</h2>
                        </AnimatedSection>
                       
                        <div className="relative min-h-[250px] flex items-center justify-center">
                            <AnimatePresence mode="wait">
                                <motion.div
                                    key={currentIndex}
                                    initial={{ opacity: 0, y: 20 }}
                                    animate={{ opacity: 1, y: 0 }}
                                    exit={{ opacity: 0, y: -20 }}
                                    transition={{ duration: 0.5, ease: 'easeInOut' }}
                                    className="w-full text-center max-w-2xl"
                                >
                                    <Icon name="quote" className="w-8 h-8 text-brand-accent mx-auto mb-4" />
                                    <p className="text-gray-600 italic text-lg">"{TESTIMONIALS[currentIndex].quote}"</p>
                                    <div className="mt-6">
                                        <p className="font-bold text-brand-primary">{TESTIMONIALS[currentIndex].author}</p>
                                        <p className="text-sm text-gray-500">{TESTIMONIALS[currentIndex].location}</p>
                                    </div>
                                </motion.div>
                            </AnimatePresence>
                        </div>
                        
                        {/* Navigation Dots */}
                        <div className="flex justify-center space-x-2 mt-8">
                            {TESTIMONIALS.map((_, index) => (
                                <button
                                    key={index}
                                    onClick={() => goToSlide(index)}
                                    className={`w-2.5 h-2.5 rounded-full transition-colors duration-300 ${
                                        currentIndex === index ? 'bg-brand-primary' : 'bg-gray-400 hover:bg-gray-500'
                                    }`}
                                    aria-label={`Go to testimonial ${index + 1}`}
                                ></button>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
}


/**
 * The main component for the Home page.
 * It assembles all the sections and manages the state for the Quick View modal.
 */
const Home: React.FC = () => {
  // State to hold the product currently being shown in the Quick View modal.
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

  // Function to open the modal with a specific product.
  const handleQuickView = (product: Product) => {
      setSelectedProduct(product);
  };

  // Function to close the modal.
  const handleCloseModal = () => {
      setSelectedProduct(null);
  };
  
  return (
    <>
      <HeroSection />
      <CategoryGrid />
      <FeaturedProducts onQuickView={handleQuickView} />
      <SaleBanner />
      <AboutIntro />
      <Testimonials />
      {/* Conditionally render the Quick View modal with an animation */}
      <AnimatePresence>
        {selectedProduct && <QuickViewModal product={selectedProduct} onClose={handleCloseModal} />}
      </AnimatePresence>
    </>
  );
};

export default Home;