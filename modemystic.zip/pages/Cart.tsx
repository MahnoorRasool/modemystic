import React from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../contexts/CartContext';
import Icon from '../components/Icon';
import AnimatedSection from '../components/AnimatedSection';

/**
 * The shopping cart page.
 * Displays items in the cart, allows quantity updates, and shows an order summary.
 * Redesigned for a more attractive and modern user experience.
 */
const Cart: React.FC = () => {
    // Destructure all necessary state and functions from the cart context.
    const { cartItems, removeFromCart, updateQuantity, cartCount, totalPrice } = useCart();

    // Helper function to format a number as a price string.
    const formatPrice = (price: number) => {
        return `PKR ${price.toLocaleString()}`;
    }

    // If the cart is empty, display a message and a link to the shop.
    if (cartCount === 0) {
        return (
            <div className="bg-white">
                <div className="container mx-auto px-6 py-24 pt-40 text-center min-h-[70vh] flex flex-col justify-center items-center">
                    <AnimatedSection>
                        <div className="bg-gray-100 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-6">
                            <Icon name="cart" className="w-12 h-12 text-gray-400" />
                        </div>
                        <h1 className="text-3xl font-bold font-serif mb-3">Your Cart is Empty</h1>
                        <p className="text-gray-500 mb-8">Looks like you haven't added anything to your cart yet.</p>
                        <Link to="/shop" className="bg-brand-primary hover:bg-black text-white font-bold py-3 px-8 rounded-full transition-transform duration-300 hover:scale-105 inline-block shadow-lg">
                            Start Shopping
                        </Link>
                    </AnimatedSection>
                </div>
            </div>
        )
    }

    // If the cart has items, display them.
    return (
        <div className="bg-white">
            <div className="container mx-auto px-6 py-24 pt-40 min-h-screen">
                <AnimatedSection>
                    <h1 className="text-4xl font-bold text-center font-serif mb-12">Shopping Cart</h1>
                </AnimatedSection>

                <div className="grid lg:grid-cols-12 gap-x-12 gap-y-8">
                    {/* List of cart items */}
                    <div className="lg:col-span-8">
                        <AnimatedSection>
                            <div className="bg-white border border-gray-200 rounded-lg shadow-sm p-4 sm:p-6 divide-y divide-gray-200">
                                {cartItems.map(item => (
                                    <div key={item.id} className="flex flex-col sm:flex-row items-start sm:items-center justify-between py-6 first:pt-0 last:pb-0 gap-4">
                                        {/* Left side: Image & Details */}
                                        <div className="flex items-center gap-4 flex-grow">
                                            <img src={item.imageUrl} alt={item.name} className="w-24 h-32 object-cover rounded-md flex-shrink-0" />
                                            <div>
                                                <h2 className="font-semibold text-lg text-brand-primary">{item.name}</h2>
                                                <p className="text-sm text-gray-500">{item.price}</p>
                                            </div>
                                        </div>

                                        {/* Right side: Controls & Price */}
                                        <div className="flex items-center gap-3 sm:gap-6 w-full sm:w-auto">
                                            {/* Quantity controls */}
                                            <div className="flex items-center border border-gray-300 rounded-full">
                                                <button onClick={() => updateQuantity(item.id, item.quantity - 1)} className="p-2 text-gray-500 hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed rounded-l-full" aria-label={`Decrease quantity of ${item.name}`}>
                                                    <Icon name="minus" className="w-4 h-4" />
                                                </button>
                                                <span className="font-bold w-8 text-center" aria-live="polite">{item.quantity}</span>
                                                <button onClick={() => updateQuantity(item.id, item.quantity + 1)} className="p-2 text-gray-500 hover:bg-gray-100 rounded-r-full" aria-label={`Increase quantity of ${item.name}`}>
                                                    <Icon name="plus" className="w-4 h-4" />
                                                </button>
                                            </div>
                                            {/* Item subtotal */}
                                            <p className="font-bold w-24 text-right text-lg flex-shrink-0">{formatPrice(Number(item.price.replace(/[^0-9.-]+/g,"")) * item.quantity)}</p>
                                            {/* Remove button */}
                                            <button onClick={() => removeFromCart(item.id)} className="text-gray-400 hover:text-red-500 transition-colors" aria-label={`Remove ${item.name} from cart`}>
                                                <Icon name="trash" className="w-5 h-5" />
                                            </button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </AnimatedSection>
                    </div>
                    {/* Order summary sidebar */}
                    <div className="lg:col-span-4">
                        <AnimatedSection delay={0.2} className="bg-brand-secondary border border-gray-200 p-6 rounded-lg sticky top-32">
                            <h2 className="text-2xl font-bold font-serif mb-6 border-b border-gray-200 pb-4">Order Summary</h2>
                            <div className="space-y-4 text-gray-700">
                                <div className="flex justify-between">
                                    <span>Subtotal</span>
                                    <span>{formatPrice(totalPrice)}</span>
                                </div>
                                <div className="flex justify-between">
                                    <span>Shipping</span>
                                    <span className="font-medium text-brand-accent">FREE</span>
                                </div>
                                 <div className="pt-4">
                                   <label htmlFor="promo-code" className="text-sm font-medium text-gray-700">Have a promo code?</label>
                                   <div className="flex space-x-2 mt-1">
                                       <input type="text" id="promo-code" className="block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-accent focus:border-brand-accent text-sm" placeholder="Enter code" />
                                       <button className="bg-gray-800 text-white px-4 rounded-md text-sm font-semibold hover:bg-black transition-colors flex-shrink-0">Apply</button>
                                   </div>
                               </div>
                            </div>
                            <div className="border-t border-gray-200 my-6"></div>
                            <div className="flex justify-between font-bold text-xl text-brand-primary">
                                <span>Total</span>
                                <span>{formatPrice(totalPrice)}</span>
                            </div>
                            <Link to="/checkout" className="w-full mt-6 bg-brand-primary hover:bg-black text-white font-bold py-3 px-4 rounded-md shadow-lg transition-all duration-300 transform hover:scale-105 flex items-center justify-center gap-2">
                                <span>Proceed to Checkout</span>
                                <Icon name="arrow-right" className="w-5 h-5"/>
                            </Link>
                        </AnimatedSection>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Cart;