


import React, { useState } from 'react';
import { AnimatePresence } from 'framer-motion';
import { PRODUCTS } from '../constants';
import ProductCard from '../components/ProductCard';
import AnimatedSection from '../components/AnimatedSection';
import QuickViewModal from '../components/QuickViewModal';
import type { Product } from '../types';

/**
 * The Women's collection page, displaying women's products with sub-category filters.
 */
const Women: React.FC = () => {
    // State for the current sub-category filter.
    const [filter, setFilter] = useState('All');
    // State for the product selected for quick view.
    const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

    // Get all women's products
    const womensProducts = PRODUCTS.filter(p => p.category === 'Women');

    // Create a unique list of sub-categories from the women's products data.
    const subCategories = ['All', ...Array.from(new Set(womensProducts.map(p => p.subCategory).filter(Boolean))) as string[]];

    // Filter women's products based on the selected sub-category.
    const filteredProducts = filter === 'All' 
        ? womensProducts 
        : womensProducts.filter(p => p.subCategory === filter);

    // Handler to open the quick view modal.
    const handleQuickView = (product: Product) => {
        setSelectedProduct(product);
    };

    // Handler to close the quick view modal.
    const handleCloseModal = () => {
        setSelectedProduct(null);
    };

    return (
        <>
            <div className="bg-white">
                <div className="container mx-auto px-6 py-24 pt-40">
                    <AnimatedSection>
                        <h1 className="text-4xl font-bold text-center font-serif mb-4">Women's Collection</h1>
                        <p className="text-center text-gray-600 max-w-2xl mx-auto mb-12">
                            Explore our chic and modern collection for women, designed to empower and inspire.
                        </p>
                    </AnimatedSection>

                    {/* Sub-category filter buttons */}
                    <AnimatedSection delay={0.2}>
                        <div className="flex justify-center items-center space-x-2 sm:space-x-4 mb-12 flex-wrap">
                            {subCategories.map(subCategory => (
                                <button
                                    key={subCategory}
                                    onClick={() => setFilter(subCategory)}
                                    className={`px-4 py-2 my-1 text-sm font-medium rounded-full transition-all duration-300 ${
                                        filter === subCategory 
                                        ? 'bg-brand-primary text-white shadow-md' 
                                        : 'bg-white text-brand-primary hover:bg-gray-100 border'
                                    }`}
                                >
                                    {subCategory}
                                </button>
                            ))}
                        </div>
                    </AnimatedSection>

                    {/* Grid of filtered products */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-8 gap-y-12">
                        {filteredProducts.map((product) => (
                            <ProductCard key={product.id} product={product} onQuickView={handleQuickView} />
                        ))}
                    </div>

                    {filteredProducts.length === 0 && (
                        <AnimatedSection className="text-center col-span-full py-16">
                            <p className="text-gray-500">No products found in this category.</p>
                        </AnimatedSection>
                    )}


                    {/* Mock pagination controls */}
                    <AnimatedSection className="text-center mt-16">
                         <div className="flex justify-center space-x-2">
                            <button className="px-4 py-2 border border-gray-300 rounded-md">&laquo;</button>
                            <button className="px-4 py-2 bg-brand-primary text-white border border-brand-primary rounded-md">1</button>
                            <button className="px-4 py-2 border border-gray-300 rounded-md">2</button>
                            <button className="px-4 py-2 border border-gray-300 rounded-md">&raquo;</button>
                        </div>
                    </AnimatedSection>
                </div>
            </div>
            {/* Conditionally render the Quick View modal with animation */}
            <AnimatePresence>
                {selectedProduct && <QuickViewModal product={selectedProduct} onClose={handleCloseModal} />}
            </AnimatePresence>
        </>
    );
};

export default Women;