import React, { useState } from 'react';
import { AnimatePresence } from 'framer-motion';
import { PRODUCTS } from '../constants';
import ProductCard from '../components/ProductCard';
import AnimatedSection from '../components/AnimatedSection';
import QuickViewModal from '../components/QuickViewModal';
import type { Product } from '../types';

/**
 * The Sale page, which displays all products currently on sale.
 */
const Sale: React.FC = () => {
    // State for the product selected for quick view.
    const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

    // Get all products that are on sale.
    const saleProducts = PRODUCTS.filter(p => p.onSale);

    // Handler to open the quick view modal.
    const handleQuickView = (product: Product) => {
        setSelectedProduct(product);
    };

    // Handler to close the quick view modal.
    const handleCloseModal = () => {
        setSelectedProduct(null);
    };

    return (
        <>
            <div className="bg-white">
                <div className="container mx-auto px-6 py-24 pt-40">
                    <AnimatedSection>
                        <h1 className="text-4xl font-bold text-center font-serif mb-4">Mid-Season Sale</h1>
                        <p className="text-center text-gray-600 max-w-2xl mx-auto mb-12">
                            Grab these styles before they're gone! Limited time offers on selected items.
                        </p>
                    </AnimatedSection>

                    {/* Grid of filtered products */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-8 gap-y-12">
                        {saleProducts.map((product) => (
                            <ProductCard key={product.id} product={product} onQuickView={handleQuickView} />
                        ))}
                    </div>

                    {saleProducts.length === 0 && (
                        <AnimatedSection className="text-center col-span-full py-16">
                            <p className="text-gray-500">No products are currently on sale. Check back soon!</p>
                        </AnimatedSection>
                    )}
                </div>
            </div>
            {/* Conditionally render the Quick View modal with animation */}
            <AnimatePresence>
                {selectedProduct && <QuickViewModal product={selectedProduct} onClose={handleCloseModal} />}
            </AnimatePresence>
        </>
    );
};

export default Sale;
