import React from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../contexts/CartContext';
import Icon from '../components/Icon';
import AnimatedSection from '../components/AnimatedSection';

/**
 * The Checkout page.
 * A mock page for users to enter shipping and payment details.
 */
const Checkout: React.FC = () => {
    const { cartItems, totalPrice } = useCart();

    const formatPrice = (price: number) => `PKR ${price.toLocaleString()}`;

    const handlePlaceOrder = (e: React.MouseEvent<HTMLButtonElement>) => {
        e.preventDefault();
        alert('Thank you for your order! (This is a demo)');
    };

    return (
        <div className="bg-white">
            <div className="container mx-auto px-6 py-24 pt-40 min-h-screen">
                <AnimatedSection>
                    <h1 className="text-4xl font-bold text-center font-serif mb-12">Checkout</h1>
                </AnimatedSection>
                <div className="grid lg:grid-cols-12 gap-x-16 gap-y-12">
                    {/* Left side: Shipping and Payment Forms */}
                    <div className="lg:col-span-7">
                        <AnimatedSection>
                            <div className="bg-brand-secondary p-8 rounded-lg">
                                <h2 className="text-2xl font-bold font-serif mb-6">Shipping Information</h2>
                                <form className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-4">
                                    <div className="sm:col-span-2">
                                        <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email Address</label>
                                        <input type="email" id="email" className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-accent focus:border-brand-accent" />
                                    </div>
                                    <div>
                                        <label htmlFor="first-name" className="block text-sm font-medium text-gray-700">First Name</label>
                                        <input type="text" id="first-name" className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-accent focus:border-brand-accent" />
                                    </div>
                                    <div>
                                        <label htmlFor="last-name" className="block text-sm font-medium text-gray-700">Last Name</label>
                                        <input type="text" id="last-name" className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-accent focus:border-brand-accent" />
                                    </div>
                                    <div className="sm:col-span-2">
                                        <label htmlFor="address" className="block text-sm font-medium text-gray-700">Address</label>
                                        <input type="text" id="address" className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-accent focus:border-brand-accent" />
                                    </div>
                                    <div>
                                        <label htmlFor="city" className="block text-sm font-medium text-gray-700">City</label>
                                        <input type="text" id="city" className="mt-1 block w-full px-3 py-2 bg-white border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-brand-accent focus:border-brand-accent" />
                                    </div>
                                    <div>
                                        <label htmlFor="country" className="block text-sm font-medium text-gray-700">Country</label>
                                        <input type="text" id="country" value="Pakistan" readOnly className="mt-1 block w-full px-3 py-2 bg-gray-100 border border-gray-300 rounded-md shadow-sm" />
                                    </div>
                                </form>
                            </div>
                        </AnimatedSection>
                         <AnimatedSection className="mt-8">
                            <div className="bg-brand-secondary p-8 rounded-lg">
                                <h2 className="text-2xl font-bold font-serif mb-6">Payment Details</h2>
                                <p className="text-gray-600">This is a demo store. No payment will be processed.</p>
                            </div>
                        </AnimatedSection>
                    </div>

                    {/* Right side: Order Summary */}
                    <div className="lg:col-span-5">
                        <AnimatedSection delay={0.2}>
                            <div className="bg-brand-secondary p-6 rounded-lg sticky top-32">
                                <h2 className="text-2xl font-bold font-serif mb-6">Your Order</h2>
                                <div className="divide-y divide-gray-200">
                                    {cartItems.map(item => (
                                        <div key={item.id} className="flex items-center justify-between py-4">
                                            <div className="flex items-center gap-4">
                                                <img src={item.imageUrl} alt={item.name} className="w-16 h-20 object-cover rounded-md" />
                                                <div>
                                                    <p className="font-semibold">{item.name}</p>
                                                    <p className="text-sm text-gray-500">Qty: {item.quantity}</p>
                                                </div>
                                            </div>
                                            <p className="font-medium">{formatPrice(Number(item.price.replace(/[^0-9.-]+/g,"")) * item.quantity)}</p>
                                        </div>
                                    ))}
                                </div>
                                <div className="border-t border-gray-200 my-4"></div>
                                <div className="space-y-2">
                                    <div className="flex justify-between text-gray-600">
                                        <span>Subtotal</span>
                                        <span>{formatPrice(totalPrice)}</span>
                                    </div>
                                    <div className="flex justify-between text-gray-600">
                                        <span>Shipping</span>
                                        <span className="text-brand-accent font-medium">FREE</span>
                                    </div>
                                    <div className="flex justify-between font-bold text-lg pt-2">
                                        <span>Total</span>
                                        <span>{formatPrice(totalPrice)}</span>
                                    </div>
                                </div>
                                <button
                                    onClick={handlePlaceOrder}
                                    className="w-full mt-6 bg-brand-primary hover:bg-black text-white font-bold py-3 px-4 rounded-md shadow-lg transition-all duration-300 transform hover:scale-105 flex items-center justify-center gap-2"
                                >
                                    <span>Place Order</span>
                                    <Icon name="lock" className="w-5 h-5"/>
                                </button>
                            </div>
                        </AnimatedSection>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Checkout;