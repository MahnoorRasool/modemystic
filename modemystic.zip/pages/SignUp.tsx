import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Icon from '../components/Icon';
import AnimatedSection from '../components/AnimatedSection';

/**
 * The Sign Up page, redesigned for a unique, stylish, and minimalist registration experience.
 */
const SignUp: React.FC = () => {
    const navigate = useNavigate();
    const [isLoading, setIsLoading] = useState(false);

    const handleSignUp = (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        // Simulate API call for registration
        setTimeout(() => {
            setIsLoading(false);
            navigate('/'); // Redirect to home on successful signup
        }, 1500);
    };

    return (
        <div className="min-h-screen grid grid-cols-1 lg:grid-cols-2 font-sans">
            {/* Image Panel */}
            <div className="relative hidden lg:block">
                <img 
                    src="https://images.unsplash.com/photo-1524504388940-b1c1722653e1?q=80&w=1887&auto=format&fit=crop"
                    alt="A stylish woman posing for a fashion shoot"
                    className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/25 to-transparent"></div>
            </div>

            {/* Form Panel */}
            <div 
                className="flex items-center justify-center bg-brand-secondary p-4 pt-24 pb-12 lg:pt-12"
            >
                <AnimatedSection className="w-full max-w-md">
                    <div className="bg-white p-8 md:p-12 rounded-2xl shadow-2xl relative overflow-hidden">
                         {/* Decorative Background Element */}
                        <div className="absolute -top-10 -right-10 text-[12rem] font-black text-gray-500/5 select-none pointer-events-none" aria-hidden="true">M</div>

                        {/* Header */}
                        <div className="text-center mb-10">
                            <Link to="/" className="inline-block mb-6">
                                <img src="https://storage.googleapis.com/fpl-v2-prompt-images/modemystic-logo-black.png" alt="ModeMystic Logo" className="h-12 w-auto mx-auto" />
                            </Link>
                            <h1 className="font-serif text-3xl md:text-4xl font-bold text-brand-primary">Create an Account</h1>
                            <p className="mt-2 text-gray-600">
                                Already have one?{' '}
                                <Link to="/account" className="font-medium text-brand-primary hover:text-black underline">
                                    Sign in
                                </Link>
                            </p>
                        </div>

                        <form className="space-y-6" onSubmit={handleSignUp}>
                             {/* Full Name Input */}
                            <div className="relative">
                                 <input id="full-name" name="full-name" type="text" required className="block px-2.5 pb-2.5 pt-4 w-full text-sm text-gray-900 bg-transparent rounded-lg border border-gray-300 appearance-none focus:outline-none focus:ring-0 focus:border-brand-primary peer" placeholder=" "/>
                                 <label htmlFor="full-name" className="absolute text-sm text-gray-500 duration-300 transform -translate-y-4 scale-75 top-2 z-10 origin-[0] bg-white px-2 peer-focus:px-2 peer-focus:text-brand-primary peer-placeholder-shown:scale-100 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:top-1/2 peer-focus:top-2 peer-focus:scale-75 peer-focus:-translate-y-4 start-1">Full Name</label>
                            </div>
                            {/* Email Input */}
                            <div className="relative">
                                <input id="email" name="email" type="email" required className="block px-2.5 pb-2.5 pt-4 w-full text-sm text-gray-900 bg-transparent rounded-lg border border-gray-300 appearance-none focus:outline-none focus:ring-0 focus:border-brand-primary peer" placeholder=" "/>
                                <label htmlFor="email" className="absolute text-sm text-gray-500 duration-300 transform -translate-y-4 scale-75 top-2 z-10 origin-[0] bg-white px-2 peer-focus:px-2 peer-focus:text-brand-primary peer-placeholder-shown:scale-100 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:top-1/2 peer-focus:top-2 peer-focus:scale-75 peer-focus:-translate-y-4 start-1">Email address</label>
                            </div>
                            {/* Password Input */}
                            <div className="relative">
                                 <input id="password" name="password" type="password" required className="block px-2.5 pb-2.5 pt-4 w-full text-sm text-gray-900 bg-transparent rounded-lg border border-gray-300 appearance-none focus:outline-none focus:ring-0 focus:border-brand-primary peer" placeholder=" "/>
                                 <label htmlFor="password" className="absolute text-sm text-gray-500 duration-300 transform -translate-y-4 scale-75 top-2 z-10 origin-[0] bg-white px-2 peer-focus:px-2 peer-focus:text-brand-primary peer-placeholder-shown:scale-100 peer-placeholder-shown:-translate-y-1/2 peer-placeholder-shown:top-1/2 peer-focus:top-2 peer-focus:scale-75 peer-focus:-translate-y-4 start-1">Password</label>
                            </div>
                            
                            <div className="flex items-start gap-3 pt-2">
                                <input id="terms" name="terms" type="checkbox" required className="h-4 w-4 mt-0.5 flex-shrink-0 rounded border-gray-300 text-brand-primary focus:ring-brand-primary focus:ring-offset-0"/>
                                <label htmlFor="terms" className="text-gray-600 text-sm">
                                    I agree to the <a href="#" className="font-medium text-brand-primary underline">Terms of Service</a> and <a href="#" className="font-medium text-brand-primary underline">Privacy Policy</a>.
                                </label>
                            </div>

                            <div>
                                <button
                                    type="submit"
                                    disabled={isLoading}
                                    className="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-brand-primary hover:bg-black focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-primary transition-colors duration-300 disabled:bg-opacity-70 disabled:cursor-not-allowed"
                                >
                                    {isLoading ? (
                                        <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                                    ) : (
                                        'Create Account'
                                    )}
                                </button>
                            </div>
                        </form>
                    </div>
                </AnimatedSection>
            </div>
        </div>
    );
};

export default SignUp;