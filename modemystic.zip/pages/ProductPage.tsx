import React, { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { PRODUCTS } from '../constants';
import { useCart } from '../contexts/CartContext';
import Icon from '../components/Icon';
import AnimatedSection from '../components/AnimatedSection';
import ProductCard from '../components/ProductCard';
import { Product } from '../types';
import { AnimatePresence } from 'framer-motion';
import QuickViewModal from '../components/QuickViewModal';

/**
 * A dedicated page to display the details of a single product.
 */
const ProductPage: React.FC = () => {
    const { productId } = useParams<{ productId: string }>();
    const navigate = useNavigate();
    const { addToCart } = useCart();
    const [quantity, setQuantity] = useState(1);
    const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

    // Find the product based on the ID from the URL.
    const product = PRODUCTS.find(p => p.id === Number(productId));

    // Effect to scroll to top and reset quantity when product ID changes.
     React.useEffect(() => {
        window.scrollTo(0, 0);
        setQuantity(1);
    }, [productId]);

    // If no product is found, display a "not found" message.
    if (!product) {
        return (
            <div className="bg-white">
                <div className="container mx-auto px-6 py-24 pt-40 text-center min-h-[70vh] flex flex-col justify-center items-center">
                    <AnimatedSection>
                        <h1 className="text-3xl font-bold font-serif mb-3">Product Not Found</h1>
                        <p className="text-gray-500 mb-8">Sorry, we couldn't find the product you're looking for.</p>
                        <Link to="/shop" className="bg-brand-primary hover:bg-black text-white font-bold py-3 px-8 rounded-full transition-transform duration-300 hover:scale-105 inline-block shadow-lg">
                            Back to Shop
                        </Link>
                    </AnimatedSection>
                </div>
            </div>
        );
    }
    
    /**
     * Safely updates the quantity, ensuring it doesn't go below 1.
     * @param amount The amount to increase or decrease by.
     */
    const handleQuantityChange = (amount: number) => {
        setQuantity(prev => Math.max(1, prev + amount));
    };

    /**
     * Adds the current product to the cart with the selected quantity.
     */
    const handleAddToCart = () => {
        addToCart(product, quantity);
        // Optionally, provide user feedback here (e.g., a toast notification).
    };

    // Find related products from the same category.
    const relatedProducts = PRODUCTS.filter(p => p.category === product.category && p.id !== product.id).slice(0, 4);
    
    const handleQuickView = (product: Product) => {
        // Since we are on a product page, clicking a related item should navigate.
        navigate(`/product/${product.id}`);
    };

    return (
        <>
            <div className="bg-white pt-32 pb-20">
                <div className="container mx-auto px-6">
                    <AnimatedSection>
                        <div className="grid md:grid-cols-2 gap-12 lg:gap-16 items-start">
                            {/* Product Image */}
                            <div className="md:sticky top-32">
                                <img src={product.imageUrl} alt={product.name} className="w-full h-auto object-cover rounded-lg shadow-lg aspect-[4/5]" />
                            </div>
                            {/* Product Details */}
                            <div>
                                {product.subCategory && (
                                    <span className="text-sm font-semibold uppercase tracking-widest text-gray-500 mb-2">{product.subCategory}</span>
                                )}
                                <h1 className="text-4xl lg:text-5xl font-bold font-serif text-brand-primary mb-4">{product.name}</h1>
                                
                                {product.onSale && product.originalPrice ? (
                                    <div className="flex items-baseline gap-3 mb-6">
                                        <p className="text-2xl text-gray-400 font-bold line-through">{product.originalPrice}</p>
                                        <p className="text-4xl text-brand-sale font-bold">{product.price}</p>
                                    </div>
                                ) : (
                                    <p className="text-3xl text-brand-accent font-bold mb-6">{product.price}</p>
                                )}

                                <div className="prose prose-lg text-gray-600 mb-8 max-w-none">
                                    <p>{product.description}</p>
                                </div>
                                
                                {/* Action bar */}
                                <div className="flex items-center gap-4 mb-8">
                                    {/* Quantity Selector */}
                                    <div className="flex items-center border border-gray-300 rounded-md">
                                        <button 
                                            onClick={() => handleQuantityChange(-1)} 
                                            disabled={quantity <= 1} 
                                            className="p-3 text-gray-500 hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed transition-colors" 
                                            aria-label="Decrease quantity"
                                        >
                                            <Icon name="minus" className="w-4 h-4" />
                                        </button>
                                        <span className="font-bold text-lg px-4" aria-live="polite">{quantity}</span>
                                        <button 
                                            onClick={() => handleQuantityChange(1)} 
                                            className="p-3 text-gray-500 hover:bg-gray-100 transition-colors" 
                                            aria-label="Increase quantity"
                                        >
                                            <Icon name="plus" className="w-4 h-4" />
                                        </button>
                                    </div>
                                    {/* Add to Cart Button */}
                                    <button
                                    onClick={handleAddToCart}
                                    className="flex-grow bg-brand-primary hover:bg-black text-white font-bold py-3 px-4 rounded-md shadow-lg transition-all duration-300 transform hover:scale-105 flex items-center justify-center gap-2"
                                    >
                                    <Icon name="cart" className="w-5 h-5"/>
                                    <span>Add to Cart</span>
                                    </button>
                                </div>
                                <div className="border-t border-gray-200 pt-6 text-sm text-gray-500">
                                    <p><span className="font-semibold text-gray-700">Category:</span> <Link to={product.category === 'Men' ? '/men' : '/women'} className="hover:underline">{product.category}</Link></p>
                                </div>
                            </div>
                        </div>
                    </AnimatedSection>
                    
                    {/* Related Products Section */}
                    {relatedProducts.length > 0 && (
                        <section className="mt-24">
                            <AnimatedSection>
                                <h2 className="text-3xl font-bold text-center font-serif mb-12">You Might Also Like</h2>
                            </AnimatedSection>
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-x-8 gap-y-12">
                                {relatedProducts.map((relatedProduct) => (
                                    <ProductCard key={relatedProduct.id} product={relatedProduct} onQuickView={handleQuickView} />
                                ))}
                            </div>
                        </section>
                    )}
                </div>
            </div>
            
            <AnimatePresence>
              {selectedProduct && <QuickViewModal product={selectedProduct} onClose={() => setSelectedProduct(null)} />}
            </AnimatePresence>
        </>
    );
};

export default ProductPage;