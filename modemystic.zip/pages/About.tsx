


import React from 'react';
import { Link } from 'react-router-dom';
import AnimatedSection from '../components/AnimatedSection';
import Icon from '../components/Icon';

/**
 * A section highlighting the company's core values.
 */
const OurValues: React.FC = () => (
    <section className="py-20 bg-white">
        <div className="container mx-auto px-6">
            <AnimatedSection className="text-center mb-16">
                <h2 className="text-3xl md:text-4xl font-bold font-serif">Our Core Values</h2>
                <p className="text-gray-600 mt-2 max-w-2xl mx-auto">The principles that guide every decision we make.</p>
            </AnimatedSection>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-10 text-center">
                <AnimatedSection>
                    <div className="bg-brand-secondary p-8 rounded-lg h-full">
                        <Icon name="star" className="w-10 h-10 text-brand-accent mx-auto mb-4" />
                        <h3 className="text-xl font-bold mb-2">Unmatched Quality</h3>
                        <p className="text-gray-600 text-sm">We are dedicated to sourcing the finest materials and employing meticulous craftsmanship to create garments that last.</p>
                    </div>
                </AnimatedSection>
                <AnimatedSection delay={0.15}>
                     <div className="bg-brand-secondary p-8 rounded-lg h-full">
                        <Icon name="leaf" className="w-10 h-10 text-brand-accent mx-auto mb-4" />
                        <h3 className="text-xl font-bold mb-2">Ethical & Sustainable</h3>
                        <p className="text-gray-600 text-sm">We're committed to responsible production, ensuring fair labor practices and minimizing our environmental footprint.</p>
                    </div>
                </AnimatedSection>
                <AnimatedSection delay={0.3}>
                     <div className="bg-brand-secondary p-8 rounded-lg h-full">
                        <Icon name="light-bulb" className="w-10 h-10 text-brand-accent mx-auto mb-4" />
                        <h3 className="text-xl font-bold mb-2">Modern Design</h3>
                        <p className="text-gray-600 text-sm">Our aesthetic is clean, contemporary, and versatile, designed for the modern individual who values style and function.</p>
                    </div>
                </AnimatedSection>
            </div>
        </div>
    </section>
);


/**
 * The About Us page, redesigned for a more elegant, clean, and narrative-driven experience.
 */
const About: React.FC = () => {
    return (
        <div className="bg-white text-brand-primary">
            {/* Hero Section */}
            <section className="relative h-[70vh] min-h-[500px] flex items-center justify-center pt-24">
                <div className="absolute inset-0 bg-black/40 z-10"></div>
                <img 
                    src="https://plus.unsplash.com/premium_photo-1726837275299-d9729a012532?q=80&w=870&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" 
                    alt="Stylish clothes on a rack in a well-lit boutique" 
                    className="absolute inset-0 w-full h-full object-cover" 
                />
                <AnimatedSection className="relative z-20 text-center text-white p-6">
                    <h1 className="text-5xl md:text-7xl font-extrabold tracking-tighter">Our Story</h1>
                    <p className="mt-4 max-w-2xl mx-auto text-lg md:text-xl font-light">
                        We believe fashion is more than just clothing—it's a language, a form of art, and a personal statement.
                    </p>
                </AnimatedSection>
            </section>
            
            {/* Mission Section */}
            <section className="py-20 bg-brand-secondary">
                <div className="container mx-auto px-6">
                    <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">
                        <AnimatedSection>
                             <div className="relative">
                                <div className="absolute -inset-2 bg-brand-accent rounded-2xl rotate-2"></div>
                                <img 
                                    src="https://images.pexels.com/photos/7940641/pexels-photo-7940641.jpeg?auto=compress&cs=tinysrgb&w=800&h=1000&fit=crop"
                                    alt="Diverse group of friends showcasing ModeMystic's style"
                                    className="relative rounded-lg shadow-xl w-full h-auto object-cover"
                                />
                            </div>
                        </AnimatedSection>
                        <AnimatedSection delay={0.2}>
                            <h2 className="text-3xl md:text-4xl font-bold font-serif mb-4">The ModeMystic Difference</h2>
                            <p className="text-gray-600 mb-6 leading-relaxed">
                                ModeMystic was founded on a simple idea: to create beautifully designed, high-quality pieces that you'll love to wear. We focus on modern silhouettes, premium fabrics, and ethical production practices. Every collection is thoughtfully curated to empower you to express your unique style with confidence and ease.
                            </p>
                             <p className="text-gray-600 leading-relaxed">
                                From the initial sketch to the final stitch, we pour our passion for design into every garment, ensuring it not only looks good but feels incredible to wear.
                            </p>
                        </AnimatedSection>
                    </div>
                </div>
            </section>
            
            <OurValues />
            
            {/* From Sketch to Stitch Section */}
            <section className="py-20 bg-brand-secondary">
                <div className="container mx-auto px-6">
                    <AnimatedSection className="text-center mb-16">
                        <h2 className="text-3xl md:text-4xl font-bold font-serif">From Sketch to Stitch</h2>
                        <p className="text-gray-600 mt-2 max-w-2xl mx-auto">A glimpse into our creative process and commitment to craftsmanship.</p>
                    </AnimatedSection>
                    
                    <div className="space-y-20">
                        {/* Step 1 */}
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                            <AnimatedSection className="relative">
                                <div className="absolute -left-8 -top-16 text-[15rem] font-black font-serif text-gray-500/10 leading-none z-0 select-none pointer-events-none" aria-hidden="true">01</div>
                                <div className="relative z-10 pl-8 md:pl-16">
                                    <h3 className="text-2xl font-bold font-serif mb-2">Inspiration & Design</h3>
                                    <p className="text-gray-600">Our journey begins with an idea. We draw inspiration from global trends, art, and the vibrant stories of our customers to sketch designs that are both modern and timeless.</p>
                                </div>
                            </AnimatedSection>
                            <AnimatedSection delay={0.2}>
                                <div className="relative h-[450px]">
                                    <div className="absolute -inset-2 bg-gray-200 rounded-2xl rotate-2"></div>
                                    <img src="https://media.istockphoto.com/id/2170798022/photo/fashion-designer-stylish-drawings-sketches-textile-fabric-material-costume-designer-creative.jpg?s=612x612&w=0&k=20&c=8l4ujCi0cDjljoA6yAkOzKyL9YwMnzHpHlsCBHxSO_s=" alt="Fashion designer's desk with sketches and fabric samples" className="w-full h-full object-cover rounded-lg shadow-xl relative"/>
                                </div>
                            </AnimatedSection>
                        </div>
                        
                        {/* Step 2 */}
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                            <AnimatedSection className="lg:order-last relative">
                                <div className="absolute -left-8 -top-16 text-[15rem] font-black font-serif text-gray-500/10 leading-none z-0 select-none pointer-events-none" aria-hidden="true">02</div>
                                <div className="relative z-10 pl-8 md:pl-16">
                                    <h3 className="text-2xl font-bold font-serif mb-2">Material Sourcing</h3>
                                    <p className="text-gray-600">We meticulously select premium, sustainable fabrics that not only look beautiful but also feel comfortable against the skin and are kind to our planet.</p>
                                </div>
                            </AnimatedSection>
                            <AnimatedSection delay={0.2}>
                                <div className="relative h-[450px]">
                                     <div className="absolute -inset-2 bg-gray-200 rounded-2xl -rotate-2"></div>
                                    <img src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=600&h=700&fit=crop&q=80" alt="Fabric selection" className="w-full h-full object-cover rounded-lg shadow-xl relative"/>
                                </div>
                            </AnimatedSection>
                        </div>

                        {/* Step 3 */}
                        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                            <AnimatedSection className="relative">
                                <div className="absolute -left-8 -top-16 text-[15rem] font-black font-serif text-gray-500/10 leading-none z-0 select-none pointer-events-none" aria-hidden="true">03</div>
                                <div className="relative z-10 pl-8 md:pl-16">
                                    <h3 className="text-2xl font-bold font-serif mb-2">Craft & Creation</h3>
                                    <p className="text-gray-600">Our skilled artisans bring the designs to life with precision and care, focusing on every detail from the cut and fit to the final stitch.</p>
                                </div>
                            </AnimatedSection>
                             <AnimatedSection delay={0.2}>
                                <div className="relative h-[450px]">
                                     <div className="absolute -inset-2 bg-gray-200 rounded-2xl rotate-2"></div>
                                    <img src="https://plus.unsplash.com/premium_photo-1661741590278-c3bc3401916e?q=80&w=870&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D" alt="Fashion designer draping fabric on a mannequin" className="w-full h-full object-cover rounded-lg shadow-xl relative"/>
                                </div>
                             </AnimatedSection>
                        </div>
                    </div>
                </div>
            </section>
            
             {/* Join the Journey CTA */}
            <section className="bg-white py-20">
                <div className="container mx-auto px-6">
                     <AnimatedSection>
                        <div className="relative">
                            <div className="absolute -inset-2 bg-brand-accent rounded-3xl rotate-1"></div>
                            <div className="relative bg-brand-primary text-white rounded-2xl z-10 p-8 md:p-16 text-center">
                                <h2 className="text-3xl font-bold font-serif mb-4">Become Part of the Story</h2>
                                <p className="max-w-xl mx-auto mb-8 text-white/80">
                                    Discover a new era of style. Explore our latest arrivals and find the pieces that speak to you.
                                </p>
                                <Link to="/shop" className="bg-white hover:bg-gray-200 text-brand-primary font-bold py-3 px-10 rounded-full transition-all duration-300 hover:scale-105 inline-block shadow-lg">
                                    Explore the Collection
                                 </Link>
                            </div>
                        </div>
                    </AnimatedSection>
                </div>
            </section>
        </div>
    );
};

export default About;