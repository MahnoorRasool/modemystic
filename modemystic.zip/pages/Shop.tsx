


import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { AnimatePresence } from 'framer-motion';
import { PRODUCTS } from '../constants';
import ProductCard from '../components/ProductCard';
import AnimatedSection from '../components/AnimatedSection';
import QuickViewModal from '../components/QuickViewModal';
import type { Product } from '../types';

/**
 * The Shop page, which displays all products and allows filtering by sub-category.
 * This page is primarily used for links from the homepage category grid.
 */
const Shop: React.FC = () => {
    // Get the current location to read URL query parameters.
    const location = useLocation();
    const queryParams = new URLSearchParams(location.search);
    // Get the 'subCategory' from the URL, or default to 'All'.
    const initialSubCategory = queryParams.get('subCategory') || 'All';
    
    // State for the current sub-category filter.
    const [filter, setFilter] = useState('All');
    // State for the product selected for quick view.
    const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);

    // Effect to update the filter state when the URL query parameter changes.
    useEffect(() => {
        setFilter(initialSubCategory);
    }, [initialSubCategory]);

    // Create a unique list of sub-categories from the products data.
    const subCategories = ['All', ...Array.from(new Set(PRODUCTS.map(p => p.subCategory).filter(Boolean))) as string[]];
    // Filter products based on the selected sub-category.
    const filteredProducts = filter === 'All' ? PRODUCTS : PRODUCTS.filter(p => p.subCategory === filter);

    // Handler to open the quick view modal.
    const handleQuickView = (product: Product) => {
        setSelectedProduct(product);
    };

    // Handler to close the quick view modal.
    const handleCloseModal = () => {
        setSelectedProduct(null);
    };

    const pageTitle = filter === 'All' ? 'Our Collection' : filter;

    return (
        <>
            <div className="bg-white">
                <div className="container mx-auto px-6 py-24 pt-40">
                    <AnimatedSection>
                        <h1 className="text-4xl font-bold text-center font-serif mb-4">{pageTitle}</h1>
                        <p className="text-center text-gray-600 max-w-2xl mx-auto mb-12">
                            Explore our curated selection of apparel and accessories, designed for the modern individual.
                        </p>
                    </AnimatedSection>

                    {/* Sub-category filter buttons */}
                    <AnimatedSection delay={0.2}>
                        <div className="flex justify-center items-center space-x-2 sm:space-x-4 mb-12 flex-wrap">
                            {subCategories.map(subCategory => (
                                <button
                                    key={subCategory}
                                    onClick={() => setFilter(subCategory)}
                                    className={`px-4 py-2 my-1 text-sm font-medium rounded-full transition-all duration-300 ${
                                        filter === subCategory 
                                        ? 'bg-brand-primary text-white shadow-md' 
                                        : 'bg-white/80 text-brand-primary hover:bg-white border'
                                    }`}
                                >
                                    {subCategory}
                                </button>
                            ))}
                        </div>
                    </AnimatedSection>

                    {/* Grid of filtered products */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-8 gap-y-12">
                        {filteredProducts.map((product) => (
                            <ProductCard key={product.id} product={product} onQuickView={handleQuickView} />
                        ))}
                    </div>

                    {/* Mock pagination controls */}
                    <AnimatedSection className="text-center mt-16">
                         <div className="flex justify-center space-x-2">
                            <button className="px-4 py-2 border border-gray-300 rounded-md">&laquo;</button>
                            <button className="px-4 py-2 bg-brand-primary text-white border border-brand-primary rounded-md">1</button>
                            <button className="px-4 py-2 border border-gray-300 rounded-md">2</button>
                            <button className="px-4 py-2 border border-gray-300 rounded-md">&raquo;</button>
                        </div>
                    </AnimatedSection>
                </div>
            </div>
            {/* Conditionally render the Quick View modal with animation */}
            <AnimatePresence>
                {selectedProduct && <QuickViewModal product={selectedProduct} onClose={handleCloseModal} />}
            </AnimatePresence>
        </>
    );
};

export default Shop;