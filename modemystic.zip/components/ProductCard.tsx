import React from 'react';
import type { Product } from '../types';
import AnimatedSection from './AnimatedSection';
import { useCart } from '../contexts/CartContext';

interface ProductCardProps {
  product: Product;
  onQuickView: (product: Product) => void; // A function to handle opening the quick view modal.
  theme?: 'light' | 'dark'; // Add a theme prop for different color schemes
}

/**
 * A card component to display a single product.
 * It includes hover effects to show action buttons and ensures uniform height in a grid.
 */
const ProductCard: React.FC<ProductCardProps> = ({ product, onQuickView, theme = 'light' }) => {
  // Get the addToCart function from the CartContext.
  const { addToCart } = useCart();
  
  const titleColor = theme === 'dark' ? 'text-brand-secondary' : 'text-brand-primary';
  const priceColor = theme === 'dark' ? 'text-gray-400' : 'text-gray-500';

  return (
    <AnimatedSection className="group block overflow-hidden bg-white border border-gray-200 rounded-lg shadow-sm hover:shadow-xl transition-shadow duration-300 h-full flex flex-col">
      <div className="relative">
        {/* Add a sale badge if the product is on sale, using the new 'brand-sale' color */}
        {product.onSale && (
          <div className="absolute top-3 right-3 bg-brand-sale text-white text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full z-10">
            Sale
          </div>
        )}
        <div className="overflow-hidden aspect-square">
          {/* Product image with a zoom-in effect on hover */}
          <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover transition-transform duration-500 ease-in-out group-hover:scale-110" />
        </div>
        {/* Overlay with action buttons that appears on hover */}
        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-all duration-300 flex items-center justify-center opacity-0 group-hover:opacity-100">
          <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2 p-2">
            <button 
              onClick={() => onQuickView(product)} 
              className="bg-white text-brand-primary px-4 py-2 text-sm font-semibold uppercase tracking-wider rounded transition-all duration-300 opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 delay-100"
            >
              Quick View
            </button>
            <button 
              onClick={() => addToCart(product)} 
              className="bg-brand-primary hover:bg-black text-white px-4 py-2 text-sm font-semibold uppercase tracking-wider rounded transition-all duration-300 opacity-0 group-hover:opacity-100 transform translate-y-2 group-hover:translate-y-0 delay-200"
            >
              Add to Cart
            </button>
          </div>
        </div>
      </div>
      <div className="p-4 text-center flex-grow flex flex-col justify-center">
        <h3 className={`text-base font-semibold ${titleColor} mb-1`}>{product.name}</h3>
        {product.onSale && product.originalPrice ? (
            <div className="flex items-baseline justify-center gap-2">
                <p className={`text-sm ${priceColor} line-through`}>{product.originalPrice}</p>
                <p className="text-base font-semibold text-brand-sale">{product.price}</p>
            </div>
        ) : (
            <p className={`text-sm ${priceColor}`}>{product.price}</p>
        )}
      </div>
    </AnimatedSection>
  );
};

export default ProductCard;