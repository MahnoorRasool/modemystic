import React from 'react';

// Defines the props for the Icon component, including the name of the icon and optional CSS classes.
interface IconProps {
  name: 'facebook' | 'instagram' | 'twitter' | 'arrow-right' | 'arrow-left' | 'quote' | 'cart' | 'close' | 'plus' | 'minus' | 'trash' | 'search' | 'user' | 'menu' | 'star' | 'lock' | 'google' | 'leaf' | 'light-bulb' | 'mail';
  className?: string;
}

/**
 * A dynamic SVG icon component.
 * It renders a specific icon based on the 'name' prop.
 */
const Icon: React.FC<IconProps> = ({ name, className = "w-5 h-5" }) => {
  // A map of icon names to their corresponding SVG path data.
  const icons = {
    facebook: <path d="M18 2h-3a5 5 0 00-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 011-1h3z" />,
    instagram: <path d="M16 11.37A4 4 0 1112.63 8 4 4 0 0116 11.37zm1.5-4.87h.01" />,
    twitter: <path d="M23 3a10.9 10.9 0 01-3.14 1.53 4.48 4.48 0 00-7.86 3v1A10.66 10.66 0 013 4s-4 9 5 13a11.64 11.64 0 01-7 2c9 5 20 0 20-11.5a4.5 4.5 0 00-.08-.83A7.72 7.72 0 0023 3z" />,
    'arrow-right': <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />,
    'arrow-left': <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19L3 12m0 0l7-7m-7 7h18" />,
    quote: <path d="M13 16h3l2-4V7H9v5l2 4zm-8 0h3l2-4V7H1v5l2 4z" />,
    cart: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />,
    close: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />,
    plus: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6v6m0 0v6m0-6h6m-6 0H6" />,
    minus: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18 12H6" />,
    trash: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />,
    search: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />,
    user: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />,
    menu: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />,
    star: <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />,
    lock: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />,
    google: <path d="M21.35,11.1H12.18V13.83H18.69C18.36,17.64 15.19,19.27 12.19,19.27C8.36,19.27 5,16.25 5,12C5,7.75 8.36,4.73 12.19,4.73C14.03,4.73 15.69,5.36 16.95,6.55L19.05,4.45C17.15,2.81 14.85,2 12.19,2C6.92,2 2.71,6.62 2.71,12C2.71,17.38 6.92,22 12.19,22C17.6,22 21.54,18.33 21.54,12.23C21.54,11.76 21.48,11.43 21.35,11.1Z" />,
    leaf: <path fillRule="evenodd" d="M17.66,3.53a2,2,0,0,0-2.2,0,7.83,7.83,0,0,1-3,1.8,7.6,7.6,0,0,0-4.3,2.4A8,8,0,0,0,6.66,12v5.17A3,3,0,0,0,12,21h.17A3,3,0,0,0,15.34,18V12A8,8,0,0,0,17.66,3.53Z" clipRule="evenodd" />,
    'light-bulb': <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />,
    mail: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
  };

  const selectedIcon = icons[name] || null;
  // Some icons use `stroke` instead of `fill`. This boolean determines which style to use.
  const strokeBased = ['arrow-right', 'arrow-left', 'cart', 'close', 'plus', 'minus', 'trash', 'search', 'user', 'menu', 'lock', 'light-bulb', 'mail'].includes(name);

  // Special case for Instagram icon which needs a surrounding rect.
  if (name === 'instagram') {
    return (
        <svg xmlns="http://www.w3.org/2000/svg" className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
            {selectedIcon}
        </svg>
    )
  }
  
  // Render stroke-based icons with `fill="none"` and `stroke="currentColor"`.
  if (strokeBased) {
      return (
        <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            {selectedIcon}
        </svg>
      )
  }

  // Render fill-based icons with `fill="currentColor"`.
  return (
    <svg className={className} fill="currentColor" viewBox="0 0 24 24">
      {selectedIcon}
    </svg>
  );
};

export default Icon;