
import React from 'react';
import { Link } from 'react-router-dom';
import AnimatedSection from './AnimatedSection';
import { motion, Variants } from 'framer-motion';

/**
 * A full-width banner to advertise a sale.
 * Redesigned for a clean, modern, split-layout experience with a new color scheme.
 */
const SaleBanner: React.FC = () => {
    // Animation variants for staggered text fade-in effect
    const containerVariants: Variants = {
        hidden: { opacity: 0 },
        visible: {
            opacity: 1,
            transition: { staggerChildren: 0.1, delayChildren: 0.2 },
        },
    };

    const itemVariants: Variants = {
        hidden: { opacity: 0, x: -20 },
        visible: { opacity: 1, x: 0, transition: { duration: 0.6, ease: 'easeOut' } },
    };

    return (
        <section className="py-20 bg-white">
            <div className="container mx-auto px-6">
                <AnimatedSection>
                    <div className="bg-gradient-to-br from-hero-green to-hero-orange bg-[size:200%_200%] animate-gradient rounded-2xl shadow-xl overflow-hidden grid lg:grid-cols-2 items-center">
                        {/* Image Section */}
                        <div className="relative h-80 lg:h-[500px] overflow-hidden">
                            <img 
                                src="https://images.unsplash.com/photo-1529139574466-a303027c1d8b?w=800&q=80"
                                alt="Stylish woman in a pink coat, looking over her shoulder"
                                className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 ease-in-out hover:scale-110"
                            />
                        </div>

                        {/* Content Section */}
                        <motion.div 
                            className="p-8 md:p-16 text-left"
                            variants={containerVariants}
                            initial="hidden"
                            whileInView="visible"
                            viewport={{ once: true, amount: 0.5 }}
                        >
                            <motion.h2 
                                className="text-sm font-bold uppercase tracking-widest text-brand-primary/60 mb-4"
                                variants={itemVariants}
                            >
                                Mid-Season Madness
                            </motion.h2>
                            <motion.p 
                                className="text-5xl md:text-6xl font-extrabold leading-tight tracking-tighter text-brand-primary drop-shadow-sm"
                                variants={itemVariants}
                            >
                                Up to 50% Off
                            </motion.p>
                            <motion.p 
                                className="mt-4 text-lg max-w-md text-brand-primary/80"
                                variants={itemVariants}
                            >
                                Refresh your wardrobe with our latest styles. Limited time offer on selected items.
                            </motion.p>
                            <motion.div variants={itemVariants}>
                                <Link 
                                    to="/sale" 
                                    className="mt-8 inline-block bg-brand-primary hover:bg-black text-white font-bold py-3 px-10 rounded-full transition-all duration-300 transform hover:scale-105 shadow-lg"
                                >
                                    Shop The Sale
                                </Link>
                            </motion.div>
                        </motion.div>
                    </div>
                </AnimatedSection>
            </div>
        </section>
    );
}

export default SaleBanner;
