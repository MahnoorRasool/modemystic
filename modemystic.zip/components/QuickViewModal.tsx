import React, { useState } from 'react';
import { motion } from 'framer-motion';
import type { Product } from '../types';
import { useCart } from '../contexts/CartContext';
import Icon from './Icon';

interface QuickViewModalProps {
  product: Product; // The product to display in the modal.
  onClose: () => void; // Function to call when the modal should be closed.
}

/**
 * A modal dialog for a "Quick View" of a product.
 * It displays product details and an "Add to Cart" button with smooth animations.
 */
const QuickViewModal: React.FC<QuickViewModalProps> = ({ product, onClose }) => {
  const { addToCart } = useCart();
  const [quantity, setQuantity] = useState(1);

  /**
   * Handles adding the product to the cart and then closing the modal.
   */
  const handleAddToCart = () => {
    addToCart(product, quantity);
    onClose();
  };

  /**
   * Safely updates the quantity, ensuring it doesn't go below 1.
   * @param amount The amount to increase or decrease by.
   */
  const handleQuantityChange = (amount: number) => {
    setQuantity(prev => Math.max(1, prev + amount));
  };

  // Effect to add a keydown event listener to close the modal on 'Escape' key press.
  React.useEffect(() => {
    const handleEsc = (event: KeyboardEvent) => {
       if (event.key === 'Escape') {
        onClose();
       }
    };
    window.addEventListener('keydown', handleEsc);

    // Cleanup function to remove the event listener when the component unmounts.
    return () => {
      window.removeEventListener('keydown', handleEsc);
    };
  }, [onClose]);

  return (
    // The modal overlay. Clicking it will close the modal.
    <div className="fixed inset-0 bg-black bg-opacity-60 z-[100] flex items-center justify-center p-4" onClick={onClose} role="dialog" aria-modal="true">
      {/* The modal content, animated with Framer Motion. */}
      {/* e.stopPropagation() prevents clicks inside from closing the modal. */}
      <motion.div
        initial={{ opacity: 0, y: 50, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: 50, scale: 0.95 }}
        transition={{ duration: 0.4, ease: 'easeOut' }}
        className="bg-white rounded-lg shadow-2xl max-w-4xl w-full flex flex-col md:flex-row overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Product image */}
        <div className="md:w-1/2">
          <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover aspect-[4/5]" />
        </div>
        {/* Product details */}
        <div className="md:w-1/2 p-8 flex flex-col relative">
           <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-brand-accent transition-colors" aria-label="Close dialog">
              <Icon name="close" className="w-6 h-6" />
           </button>
           
           {product.subCategory && (
                <span className="text-xs font-semibold uppercase tracking-widest text-gray-500 mb-2">{product.subCategory}</span>
            )}

          <h2 className="text-3xl font-bold font-serif text-brand-primary mb-2">{product.name}</h2>
          
          {product.onSale && product.originalPrice ? (
            <div className="flex items-baseline gap-3 mb-4">
                <p className="text-2xl text-gray-400 font-bold line-through">{product.originalPrice}</p>
                <p className="text-3xl text-brand-sale font-bold">{product.price}</p>
            </div>
          ) : (
            <p className="text-2xl text-brand-accent font-bold mb-4">{product.price}</p>
          )}

          <div className="flex-grow overflow-y-auto mb-6 pr-2">
            <p className="text-gray-600 leading-relaxed">{product.description}</p>
          </div>
          
          {/* Action bar at the bottom */}
          <div className="mt-auto pt-6 border-t border-gray-200 flex items-center gap-4">
            {/* Quantity Selector */}
            <div className="flex items-center border border-gray-300 rounded-md">
                <button 
                    onClick={() => handleQuantityChange(-1)} 
                    disabled={quantity <= 1} 
                    className="p-3 text-gray-500 hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed transition-colors" 
                    aria-label="Decrease quantity"
                >
                    <Icon name="minus" className="w-4 h-4" />
                </button>
                <span className="font-bold text-lg px-4" aria-live="polite">{quantity}</span>
                <button 
                    onClick={() => handleQuantityChange(1)} 
                    className="p-3 text-gray-500 hover:bg-gray-200 transition-colors" 
                    aria-label="Increase quantity"
                >
                    <Icon name="plus" className="w-4 h-4" />
                </button>
            </div>
            {/* Add to Cart Button */}
            <button
              onClick={handleAddToCart}
              className="flex-grow bg-brand-primary hover:bg-black text-white font-bold py-3 px-4 rounded-md shadow-lg transition-all duration-300 transform hover:scale-105 flex items-center justify-center gap-2"
            >
              <Icon name="cart" className="w-5 h-5"/>
              <span>Add to Cart</span>
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default QuickViewModal;