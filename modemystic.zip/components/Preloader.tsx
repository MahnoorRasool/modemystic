import React from 'react';
import { motion } from 'framer-motion';

/**
 * A preloader component that displays while the main app is loading.
 * It shows an elegant animation and smoothly fades out.
 */
const Preloader: React.FC = () => {
  return (
    <motion.div
      // Defines the animation for when the preloader exits (is removed from the DOM).
      exit={{ opacity: 0, transition: { duration: 0.8, ease: 'easeInOut' } }}
      className="fixed inset-0 z-[200] flex items-center justify-center bg-white"
    >
        <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
        >
            <motion.img
                src="https://storage.googleapis.com/fpl-v2-prompt-images/modemystic-logo-black.png"
                alt="ModeMystic Logo"
                className="h-24 w-auto"
                animate={{
                    scale: [1, 1.05, 1],
                }}
                transition={{
                    duration: 2.5,
                    repeat: Infinity,
                    ease: "easeInOut"
                }}
            />
        </motion.div>
    </motion.div>
  );
};

export default Preloader;