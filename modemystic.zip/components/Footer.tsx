

import React from 'react';
import { Link } from 'react-router-dom';
import { NAV_LINKS } from '../constants';
import Icon from './Icon';

/**
 * The footer component for the website.
 * Contains navigation links, social media icons, and copyright info.
 */
const Footer: React.FC = () => {
    return (
        <footer className="bg-brand-primary text-brand-secondary">
            <div className="container mx-auto px-6 py-16">
                {/* Top section with links */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-10 mb-12">
                    {/* Brand information */}
                    <div className="md:col-span-1">
                        <Link to="/" className="mb-4 inline-block">
                          <img src="https://storage.googleapis.com/fpl-v2-prompt-images/modemystic-logo-white.png" alt="ModeMystic Logo" className="h-12 w-auto" />
                        </Link>
                        <p className="text-sm text-gray-400 max-w-xs">
                            Unique clothing for the modern trendsetter, crafted with passion and designed to tell your story.
                        </p>
                    </div>

                    {/* Quick navigation links */}
                    <div className="md:justify-self-center">
                        <h4 className="font-semibold tracking-wider uppercase mb-4 text-white">Explore</h4>
                        <ul className="space-y-3">
                            {NAV_LINKS.map(link => (
                                <li key={link.path}>
                                    <Link to={link.path} className="text-gray-400 hover:text-white transition-colors duration-300 text-sm">{link.name}</Link>
                                </li>
                            ))}
                        </ul>
                    </div>

                    {/* Customer support links */}
                    <div className="md:justify-self-center">
                        <h4 className="font-semibold tracking-wider uppercase mb-4 text-white">Support</h4>
                        <ul className="space-y-3 text-sm">
                            {/* All support links now point to the contact page */}
                            <li><Link to="/contact" className="text-gray-400 hover:text-white transition-colors duration-300">FAQ</Link></li>
                            <li><Link to="/contact" className="text-gray-400 hover:text-white transition-colors duration-300">Shipping & Returns</Link></li>
                            <li><Link to="/contact" className="text-gray-400 hover:text-white transition-colors duration-300">Size Guide</Link></li>
                             <li><Link to="/contact" className="text-gray-400 hover:text-white transition-colors duration-300">Contact Us</Link></li>
                        </ul>
                    </div>
                </div>

                {/* Bottom section with copyright and social links */}
                <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row items-center justify-between">
                    <p className="text-gray-500 text-sm text-center md:text-left mb-4 md:mb-0">
                        &copy; {new Date().getFullYear()} ModeMystic. All Rights Reserved.
                    </p>
                    <div className="flex space-x-5">
                        <a href="#" aria-label="Twitter" className="text-gray-400 hover:text-white transition-colors"><Icon name="twitter" /></a>
                        <a href="#" aria-label="Facebook" className="text-gray-400 hover:text-white transition-colors"><Icon name="facebook" /></a>
                        <a href="#" aria-label="Instagram" className="text-gray-400 hover:text-white transition-colors"><Icon name="instagram" /></a>
                    </div>
                </div>
            </div>
        </footer>
    );
};

export default Footer;