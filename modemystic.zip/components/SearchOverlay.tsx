import React, { useEffect, useRef, useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link } from 'react-router-dom';
import Icon from './Icon';
import { PRODUCTS } from '../constants';
import type { Product } from '../types';
import { GoogleGenAI, Type } from "@google/genai";

/**
 * A custom hook to debounce a value. It's useful for delaying a function call
 * until the user has stopped typing.
 * @param value The value to debounce (e.g., a search term).
 * @param delay The debounce delay in milliseconds.
 * @returns The debounced value.
 */
function useDebounce(value: string, delay: number) {
  const [debouncedValue, setDebouncedValue] = useState(value);
  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);
    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);
  return debouncedValue;
}

interface SearchOverlayProps {
  isOpen: boolean;
  onClose: () => void;
}

/**
 * A full-screen search overlay component with AI-powered, real-time filtering.
 */
const SearchOverlay: React.FC<SearchOverlayProps> = ({ isOpen, onClose }) => {
  const inputRef = useRef<HTMLInputElement>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const debouncedSearchTerm = useDebounce(searchTerm, 500);

  const runSearch = useCallback(async (query: string) => {
    if (query.length < 3) {
      setSearchResults([]);
      setIsLoading(false);
      setError(null);
      return;
    }

    setIsLoading(true);
    setError(null);

    try {
      if (!process.env.API_KEY) {
          throw new Error("API key not found.");
      }
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const simplifiedProducts = PRODUCTS.map(({ id, name, description, category, subCategory, onSale }) => ({ id, name, description, category, subCategory, onSale }));
      
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: `Based on the user query "${query}", find relevant products from this list: ${JSON.stringify(simplifiedProducts)}. Prioritize direct name matches, but also consider descriptions, categories, and intent (e.g., 'warm clothes' for hoodies).`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              productIds: {
                type: Type.ARRAY,
                items: {
                  type: Type.NUMBER,
                  description: 'The unique ID of a matching product.'
                }
              }
            },
            required: ['productIds']
          },
        },
      });

      const responseJson = JSON.parse(response.text);
      const productIds = responseJson.productIds || [];

      if (productIds.length > 0) {
        const foundProducts = productIds.map((id: number) => PRODUCTS.find(p => p.id === id)).filter(Boolean);
        setSearchResults(foundProducts as Product[]);
      } else {
        setSearchResults([]);
      }
    } catch (e) {
      console.error("AI Search Error:", e);
      setError("Sorry, we couldn't use AI search. Showing basic results.");
      const fallbackResults = PRODUCTS.filter(p => p.name.toLowerCase().includes(query.toLowerCase()));
      setSearchResults(fallbackResults);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    runSearch(debouncedSearchTerm);
  }, [debouncedSearchTerm, runSearch]);
  
  // Focus input when overlay opens and clear previous state.
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 300);
      setSearchTerm('');
      setSearchResults([]);
      setError(null);
    }
  }, [isOpen]);
  
  // Add event listener to close overlay on 'Escape' key press.
  useEffect(() => {
    const handleEsc = (event: KeyboardEvent) => {
       if (event.key === 'Escape') {
        onClose();
       }
    };
    window.addEventListener('keydown', handleEsc);
    return () => window.removeEventListener('keydown', handleEsc);
  }, [onClose]);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="fixed inset-0 bg-black bg-opacity-70 backdrop-blur-sm z-[150] flex items-start justify-center p-4 pt-20 sm:pt-32"
          onClick={onClose}
          aria-modal="true"
          role="dialog"
        >
          <motion.div
            initial={{ y: -50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -50, opacity: 0 }}
            transition={{ duration: 0.4, ease: 'easeOut' }}
            className="relative w-full max-w-2xl bg-white rounded-lg shadow-2xl overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="relative">
              <input
                ref={inputRef}
                type="search"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search for products..."
                className="w-full py-4 pl-12 pr-12 text-lg border-b border-gray-200 focus:outline-none focus:ring-0 focus:border-brand-accent"
                aria-label="Search for products"
              />
              <div className="absolute top-0 left-0 flex items-center h-full pl-4 text-gray-400 pointer-events-none">
                <Icon name="search" className="w-6 h-6" />
              </div>
              <button
                onClick={onClose}
                className="absolute top-0 right-0 flex items-center h-full px-4 text-gray-400 hover:text-brand-primary transition-colors"
                aria-label="Close search"
              >
                <Icon name="close" className="w-6 h-6" />
              </button>
            </div>
            
            <div className="p-2 max-h-[50vh] overflow-y-auto">
              {isLoading && (
                <div className="flex justify-center items-center p-8">
                  <div className="w-6 h-6 border-2 border-brand-accent border-t-transparent rounded-full animate-spin"></div>
                  <p className="ml-4 text-gray-500">Searching with AI...</p>
                </div>
              )}
              {!isLoading && error && (
                <p className="text-center text-red-500 p-8">{error}</p>
              )}
              {!isLoading && debouncedSearchTerm.length > 2 && (
                searchResults.length > 0 ? (
                  <ul className="space-y-1">
                     {searchResults.map(product => (
                         <li key={product.id}>
                             <Link to={`/product/${product.id}`} onClick={onClose} className="flex items-center p-3 rounded-md hover:bg-brand-secondary transition-colors group">
                                 <img src={product.imageUrl} alt={product.name} className="w-12 h-16 object-cover rounded-md mr-4 flex-shrink-0"/>
                                 <div className="flex-grow">
                                     <p className="font-semibold group-hover:text-brand-accent transition-colors">{product.name}</p>
                                     <p className="text-sm text-gray-500">{product.price}</p>
                                 </div>
                                 <Icon name="arrow-right" className="w-5 h-5 text-gray-400 ml-4 group-hover:text-brand-accent transition-transform transform group-hover:translate-x-1" />
                             </Link>
                         </li>
                     ))}
                  </ul>
                ) : (
                  <p className="text-center text-gray-500 p-8">No products found for "{debouncedSearchTerm}"</p>
                )
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default SearchOverlay;