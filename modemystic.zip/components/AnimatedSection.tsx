import React from 'react';
import { motion } from 'framer-motion';

interface AnimatedSectionProps {
  children: React.ReactNode;
  className?: string;
  delay?: number; // Delay in seconds (e.g., 0.2 for 200ms)
}

/**
 * A wrapper component that animates its children when they become visible in the viewport.
 * It uses Framer Motion's `whileInView` for a powerful and simple implementation.
 */
const AnimatedSection: React.FC<AnimatedSectionProps> = ({ children, className = '', delay = 0 }) => {
  return (
    <motion.div
      // Initial state of the animation (before entering the viewport)
      initial={{ opacity: 0, y: 20 }}
      // State to animate to when the component is in view
      whileInView={{ opacity: 1, y: 0 }}
      // Configuration for the viewport trigger
      viewport={{ once: true, amount: 0.1 }} // `once: true` prevents re-animation on scroll
      // Transition properties like duration, delay, and easing
      transition={{ duration: 0.8, delay, ease: "easeOut" }}
      className={className}
    >
      {children}
    </motion.div>
  );
};

export default AnimatedSection;