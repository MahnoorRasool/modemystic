import React from 'react';
import { motion, Variants, Transition } from 'framer-motion';

// Defines the animation variants for page transitions.
const pageVariants: Variants = {
  initial: { // State before animation starts
    opacity: 0,
    y: 20,
    scale: 0.98,
  },
  in: { // State when page is animating in
    opacity: 1,
    y: 0,
    scale: 1,
  },
  out: { // State when page is animating out
    opacity: 0,
    y: -20,
    scale: 1.02,
  },
};

// Defines the timing and easing for the page transitions.
const pageTransition: Transition = {
  type: 'tween',
  ease: 'anticipate', // An easing function that creates a slight anticipation effect.
  duration: 0.6,
};

/**
 * A wrapper component that applies a consistent enter/exit animation
 * to pages when they are rendered.
 */
const PageTransition: React.FC<{ children: React.ReactNode }> = ({ children }) => (
  <motion.div
    initial="initial"
    animate="in"
    exit="out"
    variants={pageVariants}
    transition={pageTransition}
  >
    {children}
  </motion.div>
);

export default PageTransition;