import React, { useState, useEffect } from 'react';
import { Link, NavLink as RouterNavLink, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { NAV_LINKS } from '../constants';
import type { NavLink } from '../types';
import { useCart } from '../contexts/CartContext';
import Icon from './Icon';

/**
 * A reusable navigation link item for the desktop navbar.
 */
const NavLinkItem: React.FC<{ link: NavLink, navTextColor: string }> = ({ link, navTextColor }) => {
    // Special styling for the 'Sale' link to make it stand out.
    if (link.name === 'Sale') {
        return (
            <RouterNavLink
              to={link.path}
              className={({ isActive }) =>
                `relative font-medium text-sm tracking-wider uppercase transition-colors duration-300 after:content-[''] after:absolute after:left-0 after:bottom-[-4px] after:h-[2px] after:w-0 after:bg-brand-sale after:transition-all after:duration-300 hover:after:w-full font-semibold ${
                  isActive ? 'text-brand-sale after:w-full' : 'text-brand-sale'
                }`
              }
            >
              {link.name}
            </RouterNavLink>
        );
    }

    // Default styling for all other navigation links.
    return (
        <RouterNavLink
          to={link.path}
          className={({ isActive }) =>
            `relative font-medium text-sm tracking-wider uppercase transition-colors duration-300 after:content-[''] after:absolute after:left-0 after:bottom-[-4px] after:h-[2px] after:w-0 after:bg-brand-accent after:transition-all after:duration-300 hover:after:w-full ${
              isActive ? 'text-brand-accent after:w-full' : navTextColor
            }`
          }
        >
          {link.name}
        </RouterNavLink>
    );
};

/**
 * A reusable navigation link item for the mobile menu.
 */
const MobileNavLink: React.FC<{ link: NavLink; onClick: () => void; }> = ({ link, onClick }) => (
    <RouterNavLink
      to={link.path}
      onClick={onClick}
      className={({ isActive }) => {
            const baseClasses = 'block py-3 text-3xl font-semibold tracking-wider text-center uppercase transition-colors duration-300';
            // Apply a distinct red color for the 'Sale' link in the mobile menu.
            if (link.name === 'Sale') {
                return `${baseClasses} text-brand-sale`;
            }
            // Apply accent color for the active link, and default colors for others.
            return `${baseClasses} ${isActive ? 'text-brand-accent' : 'text-white hover:text-brand-accent'}`;
        }
      }
    >
      {link.name}
    </RouterNavLink>
);


interface NavbarProps {
    onSearchClick: () => void;
}

/**
 * The main navigation bar component for the website.
 * It's responsive, becomes sticky, and changes background on scroll.
 */
const Navbar: React.FC<NavbarProps> = ({ onSearchClick }) => {
    const [isScrolled, setIsScrolled] = useState(false);
    const [isMenuOpen, setIsMenuOpen] = useState(false);
    const { cartCount } = useCart();
    
    // Effect to handle scroll detection
    useEffect(() => {
        const handleScroll = () => {
            setIsScrolled(window.scrollY > 10);
        };
        window.addEventListener('scroll', handleScroll);
        return () => window.removeEventListener('scroll', handleScroll);
    }, []);
    
    // Effect to lock body scroll when mobile menu is open
    useEffect(() => {
        if (isMenuOpen) {
            document.body.style.overflow = 'hidden';
        } else {
            document.body.style.overflow = 'auto';
        }
        return () => { document.body.style.overflow = 'auto'; };
    }, [isMenuOpen]);
    
    // Determine text color based on scroll, page, and mobile menu state
    const navTextColor = 'text-brand-primary';
    const hamburgerColor = isMenuOpen ? 'text-white' : navTextColor;

    return (
        <>
            <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${isScrolled ? 'bg-white/95 shadow-md backdrop-blur-sm' : 'bg-white'}`}>
                <div className="container mx-auto px-6 py-3">
                    <div className="flex items-center justify-between">
                        {/* Logo linking to homepage */}
                        <Link to="/" className="relative z-[60]">
                           <img src="https://storage.googleapis.com/fpl-v2-prompt-images/modemystic-logo-black.png" alt="ModeMystic Logo" className="h-10 w-auto" />
                        </Link>
                        
                        <div className="flex items-center">
                            {/* Desktop navigation */}
                            <nav className="hidden md:flex items-center space-x-8 mr-8">
                                {NAV_LINKS.map((link) => (
                                    <NavLinkItem key={link.name} link={link} navTextColor={navTextColor} />
                                ))}
                            </nav>

                             {/* Desktop action icons */}
                            <div className="hidden md:flex items-center space-x-6">
                                <button onClick={onSearchClick} className={`${navTextColor} hover:text-brand-accent transition-colors`} aria-label="Search">
                                    <Icon name="search" className="w-5 h-5"/>
                                </button>
                                <Link to="/account" className={`${navTextColor} hover:text-brand-accent transition-colors`} aria-label="Account">
                                    <Icon name="user" className="w-5 h-5"/>
                                </Link>
                                <Link to="/cart" className={`relative ${navTextColor} hover:text-brand-accent transition-colors`} aria-label="Shopping Cart">
                                   <Icon name="cart" className="w-5 h-5"/>
                                   {cartCount > 0 && (
                                     <span className="absolute -top-2 -right-3 bg-brand-accent text-white text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center">
                                       {cartCount}
                                     </span>
                                   )}
                                </Link>
                            </div>

                            {/* Mobile menu button (hamburger/close icon) */}
                            <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="md:hidden z-[60] relative" aria-label={isMenuOpen ? 'Close menu' : 'Open menu'}>
                                <Icon name={isMenuOpen ? 'close' : 'menu'} className={`w-7 h-7 transition-colors duration-300 ${hamburgerColor}`}/>
                            </button>
                        </div>
                    </div>
                </div>
            </header>

            {/* Mobile Menu Overlay */}
            <AnimatePresence>
                {isMenuOpen && (
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        transition={{ ease: 'easeInOut', duration: 0.4 }}
                        className="fixed inset-0 bg-brand-primary/95 backdrop-blur-sm z-[55] flex flex-col items-center justify-center p-6 md:hidden"
                    >
                        <motion.nav 
                            initial="hidden"
                            animate="visible"
                            variants={{
                                visible: { transition: { staggerChildren: 0.1 } }
                            }}
                            className="flex flex-col space-y-6"
                        >
                            {NAV_LINKS.map((link) => (
                                <motion.div key={link.name} variants={{ hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 }}}>
                                    <MobileNavLink link={link} onClick={() => setIsMenuOpen(false)} />
                                </motion.div>
                            ))}
                        </motion.nav>
                        <motion.div 
                             initial={{ opacity: 0, y: 20 }}
                             animate={{ opacity: 1, y: 0 }}
                             transition={{ delay: 0.5, duration: 0.5 }}
                             className="flex items-center space-x-8 text-white mt-16"
                        >
                             <button onClick={() => { onSearchClick(); setIsMenuOpen(false); }} aria-label="Search">
                                <Icon name="search" className="w-7 h-7 hover:text-brand-accent transition-colors"/>
                            </button>
                             <Link to="/account" onClick={() => setIsMenuOpen(false)} aria-label="Account">
                                <Icon name="user" className="w-7 h-7 hover:text-brand-accent transition-colors"/>
                             </Link>
                             <Link to="/cart" onClick={() => setIsMenuOpen(false)} className="relative" aria-label="Shopping Cart">
                               <Icon name="cart" className="w-7 h-7 hover:text-brand-accent transition-colors"/>
                               {cartCount > 0 && (
                                 <span className="absolute -top-2 -right-2 bg-brand-accent text-white text-xs font-bold w-5 h-5 rounded-full flex items-center justify-center">
                                   {cartCount}
                                 </span>
                               )}
                            </Link>
                        </motion.div>
                    </motion.div>
                )}
            </AnimatePresence>
        </>
    );
};

export default Navbar;